﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator.Models
{
    class HistoryItem
    {
        public string Action { get; set; }
        public string Result { get; set; }
    }
}
