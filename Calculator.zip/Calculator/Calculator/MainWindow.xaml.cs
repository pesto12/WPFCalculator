﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Calculator.Models;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool waitingForOperand;
        private double sumSoFar;
        private double factorSoFar;
        private string pendingAdditiveOperator;
        private string pendingMultiplicationOperator;

        public MainWindow()
        {
            InitializeComponent();

            waitingForOperand = true;
            sumSoFar = 0.0;
            factorSoFar = 0.0;
            pendingAdditiveOperator = "";
            pendingMultiplicationOperator = "";
        }

        private void digit_Click(object sender, RoutedEventArgs e)
        {
            var value = Int32.Parse((sender as Button).Content.ToString());

            if(value == 0 && resultTextBox.Text == "0")
            {
                return;
            }

            if (waitingForOperand)
            {
                resultTextBox.Text = "";
                waitingForOperand = false;
            }

            resultTextBox.Text += value.ToString();
        }

        private void additiveOperator_Click(object sender, RoutedEventArgs e)
        {
            var clickedOperator = (sender as Button).Content.ToString();
            double operand = 0;
            if(!Double.TryParse(resultTextBox.Text, out operand))
            {
                operand = 0;
            }

            if(pendingMultiplicationOperator != "")
            {
                if(calculate(operand, pendingMultiplicationOperator))
                {
                    abortOperation();
                    return;
                }

                resultTextBox.Text = factorSoFar.ToString();
                operand = factorSoFar;
                factorSoFar = 0.0;
                pendingMultiplicationOperator = "";
            }

            if (pendingAdditiveOperator != "")
            {
                if (!calculate(operand, pendingAdditiveOperator))
                {
                    abortOperation();
                    return;
                }
                resultTextBox.Text = sumSoFar.ToString();
            }
            else
            {
                sumSoFar = operand;
            }

            pendingAdditiveOperator = clickedOperator;
            waitingForOperand = true;
        }

        private void multiplicativeOperator_Click(object sender, RoutedEventArgs e)
        {
            var clickedOperator = (sender as Button).Content.ToString();
            double operand = 0;
            if (!Double.TryParse(resultTextBox.Text, out operand))
            {
                operand = 0;
            }

            if (pendingMultiplicationOperator != "")
            { 
                if(!calculate(operand, pendingMultiplicationOperator))
                {
                    abortOperation();
                    return;
                }

                resultTextBox.Text = factorSoFar.ToString();
            }
            else
            {
                factorSoFar = operand;
            }

            pendingMultiplicationOperator = clickedOperator;
            waitingForOperand = true;
        }

        private void unaryOperator_Click(object sender, RoutedEventArgs e)
        {
            var result = 0.0;
            double operand = 0;
            if (!Double.TryParse(resultTextBox.Text, out operand))
            {
                operand = 0;
            }
            var clickedOperator = (sender as Button).Content.ToString();

            if(clickedOperator == "Sqrt(x)")
            {
                if(operand < 0)
                {
                    abortOperation();
                    return;
                }
                addHistoryItem(
                    new HistoryItem()
                    {
                        Action = "Sqrt(" + operand.ToString() + ")",
                        Result = (Math.Sqrt(operand)).ToString()
                    }

                );
                result = Math.Sqrt(operand);
            }
            else
            {
                if(clickedOperator == "x^2")
                {
                    addHistoryItem(
                        new HistoryItem()
                        {
                            Action = operand.ToString() + "^2",
                            Result = (Math.Pow(operand, 2)).ToString()
                        }

                    );
                    result = Math.Pow(operand, 2);
                }
                else
                {
                    if(clickedOperator == "1/x")
                    {
                        if(operand == 0.0)
                        {
                            abortOperation();
                            return;
                        }
                        addHistoryItem(
                            new HistoryItem()
                            {
                                Action = "1/" + operand.ToString(),
                                Result = (1/operand).ToString()
                            }

                        );
                        result = 1 / operand;
                    }
                }
            }
            resultTextBox.Text = result.ToString();
            waitingForOperand = true;
        }

        private void abortOperation()
        {
            clearAllClicked();
            resultTextBox.Text = "####";
        }

        private void clearAllClicked()
        {
            factorSoFar = 0.0;
            sumSoFar = 0.0;
            pendingMultiplicationOperator = "";
            pendingAdditiveOperator = "";
            waitingForOperand = true;
            resultTextBox.Text = "0";
        }

        private bool calculate(double rightOperand, string pendingOperator)
        {

            if(pendingOperator == "+")
            {
                addHistoryItem(
                    new HistoryItem()
                    {
                        Action = sumSoFar.ToString() + "+" + rightOperand.ToString(),
                        Result = (sumSoFar + rightOperand).ToString()
                    }

                );
                sumSoFar += rightOperand;
            }
            else
            {
                if(pendingOperator == "-")
                {
                    addHistoryItem(
                        new HistoryItem()
                        {
                            Action = sumSoFar.ToString() + "-" + rightOperand.ToString(),
                            Result = (sumSoFar - rightOperand).ToString()
                        }
                    );
                    sumSoFar -= rightOperand;
                }
                else
                {
                    if(pendingOperator == "*")
                    {
                        addHistoryItem(
                            new HistoryItem()
                            {
                                Action = factorSoFar.ToString() + "*" + rightOperand.ToString(),
                                Result = (factorSoFar * rightOperand).ToString()
                            }

                        );
                        factorSoFar *= rightOperand;
                    }
                    else
                    {
                        if(pendingOperator == "/")
                        {
                            if(rightOperand == 0.0)
                            {
                                return false;
                            }
                            addHistoryItem(
                                new HistoryItem()
                                {
                                    Action = factorSoFar.ToString() + "/" + rightOperand.ToString(),
                                    Result = (factorSoFar / rightOperand).ToString()
                                }

                            );
                            factorSoFar /= rightOperand;
                        }
                    }
                }
            }
            return true;
        }

        private void clearHistory_Click(object sender, RoutedEventArgs e)
        {
            historyPanel.Children.Clear();
        }

        private void equals_Click(object sender, RoutedEventArgs e)
        {
            double operand = 0;
            if(! Double.TryParse(resultTextBox.Text, out operand))
            {
                operand = 0;
            }

            if (pendingMultiplicationOperator != "")
            {
                if(!calculate(operand, pendingMultiplicationOperator))
                {
                    abortOperation();
                    return;
                }

                pendingMultiplicationOperator = "";
                resultTextBox.Text = factorSoFar.ToString();
                operand = factorSoFar;
                factorSoFar = 0;
            }

            if(pendingAdditiveOperator != "")
            {
                if(!calculate(operand, pendingAdditiveOperator)){
                    abortOperation();
                    return;
                }

                pendingAdditiveOperator = "";
            }
            else
            {
                sumSoFar = operand;
            }

            resultTextBox.Text = sumSoFar.ToString();
            sumSoFar = 0;
            waitingForOperand = true;
        }

        private void backspace_Click(object sender, RoutedEventArgs e)
        {
            if (waitingForOperand)
            {
                return;
            }
            
            if(resultTextBox.Text.Length == 0)
            {
                return;
            }

            var text = resultTextBox.Text.Substring(0, resultTextBox.Text.Length -1);

            if(text == "-")
            {
                text = "0";
            }

            if(text == "0")
            {
                text = "0";
                waitingForOperand = true;
            }

            resultTextBox.Text = text;            
        }

        private void changeSign_Click(object sender, RoutedEventArgs e)
        {
            var text = resultTextBox.Text;
            double value = 0;
            if (!Double.TryParse(resultTextBox.Text, out value))
            {
                value = 0;
            }

            if (value > 0)
            {
                text = "-" + text;
            }
            else
            {
                if(value < 0)
                {
                    text = text.Substring(1, text.Length - 1);
                }
            }

            resultTextBox.Text = text;
        }


        private void point_Click(object sender, RoutedEventArgs e)
        {
            if (waitingForOperand)
            {
                resultTextBox.Text = "0";
            }
            if (!resultTextBox.Text.Contains('.'))
            {
                resultTextBox.Text += ".";
            }

            waitingForOperand = false;
        }

        private void addHistoryItem(HistoryItem historyItem)
        {
            var graphicalItem = new WrapPanel();
            graphicalItem.MouseDown += historyItem_MouseRightButtonDown;
            graphicalItem.Children.Add(new TextBlock() { Text = historyItem.Action, FontSize = 10 });
            graphicalItem.Children.Add(new TextBlock() { Text = historyItem.Result, FontSize = 15, FontStyle = FontStyles.Oblique });
            
            historyPanel.Children.Add(graphicalItem);
        }

        private void historyItem_MouseRightButtonDown(object sender, EventArgs e)
        {
            var text = ((sender as WrapPanel).Children[1] as TextBlock).Text;
            clearAllClicked();
            resultTextBox.Text = text;
            waitingForOperand = false;
        }
    }
}
